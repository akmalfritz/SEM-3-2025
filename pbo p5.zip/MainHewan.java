
// MainHewan.java
public class MainHewan {
    public static void main(String[] args) {
        Hewan kucing = new Kucing("Mimi", "Kucing Persia");
        Hewan anjing = new Anjing("Bimo", "Anjing Labrador");

        System.out.println("=== Menampilkan info secara langsung ===");
        kucing.tampilkanInfo();
        System.out.println();
        anjing.tampilkanInfo();

        System.out.println("\n=== Contoh polymorphism: array Hewan ===");
        Hewan[] daftar = { kucing, anjing };
        for (Hewan h : daftar) {
            System.out.println("---");
            h.tampilkanInfo();
        }
    }
}

class Hewan {
    private String nama;
    private String jenis;

    public Hewan(String nama, String jenis) {
        this.nama = nama;
        this.jenis = jenis;
    }

    public String getNama() { return nama; }
    public String getJenis() { return jenis; }

    public void tampilkanInfo() {
        System.out.println("Nama : " + getNama());
        System.out.println("Jenis: " + getJenis());
        System.out.println("Suara: " + suara());
    }

    public String suara() {
        return "Suara tidak diketahui";
    }
}

class Kucing extends Hewan {
    public Kucing(String nama, String jenis) {
        super(nama, jenis);
    }

    @Override
    public String suara() {
        return "Meong.. meong";
    }

    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Catatan: Kucing ini suka tidur di siang hari.");
    }
}

class Anjing extends Hewan {
    public Anjing(String nama, String jenis) {
        super(nama, jenis);
    }

    @Override
    public String suara() {
        return "Guk guk!";
    }

    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Catatan: Anjing ini ramah terhadap keluarga.");
    }
}
