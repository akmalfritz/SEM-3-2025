
// MainKendaraan.java
public class MainKendaraan {
    public static void main(String[] args) {
        Mobil mobil = new Mobil("Toyota Avanza", 4, 7);
        SepedaMotor motor = new SepedaMotor("Honda Beat", 2, "110cc");

        System.out.println("=== Info Kendaraan ===");
        mobil.tampilkanInfo();
        System.out.println();
        motor.tampilkanInfo();

        System.out.println("\n=== Polymorphism dengan referensi Kendaraan ===");
        Kendaraan[] garasi = { mobil, motor };
        for (Kendaraan k : garasi) {
            System.out.println("---");
            k.tampilkanInfo();
        }
    }
}

class Kendaraan {
    private String merk;

    public Kendaraan(String merk) {
        this.merk = merk;
    }

    public String getMerk() { return merk; }

    public void tampilkanInfo() {
        System.out.println("Merk: " + getMerk());
    }
}

class KendaraanDarat extends Kendaraan {
    private int jumlahRoda;

    public KendaraanDarat(String merk, int jumlahRoda) {
        super(merk);
        this.jumlahRoda = jumlahRoda;
    }

    public int getJumlahRoda() { return jumlahRoda; }

    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Jumlah roda: " + getJumlahRoda());
    }
}

class Mobil extends KendaraanDarat {
    private int kapasitasPenumpang;

    public Mobil(String merk, int jumlahRoda, int kapasitasPenumpang) {
        super(merk, jumlahRoda);
        this.kapasitasPenumpang = kapasitasPenumpang;
    }

    public int getKapasitasPenumpang() { return kapasitasPenumpang; }

    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Tipe: Mobil");
        System.out.println("Kapasitas penumpang: " + getKapasitasPenumpang());
    }

    public void nyalakanAC() {
        System.out.println(getMerk() + ": AC dinyalakan.");
    }
}

class SepedaMotor extends KendaraanDarat {
    private String tipeMesin;

    public SepedaMotor(String merk, int jumlahRoda, String tipeMesin) {
        super(merk, jumlahRoda);
        this.tipeMesin = tipeMesin;
    }

    public String getTipeMesin() { return tipeMesin; }

    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Tipe: Sepeda Motor");
        System.out.println("Tipe mesin: " + getTipeMesin());
    }

    public void pakaiHelm() {
        System.out.println("Jangan lupa memakai helm saat mengendarai " + getMerk());
    }
}
